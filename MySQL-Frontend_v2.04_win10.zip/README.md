# MySQL-Frontend
A stripped-down GUI frontend developed in Python3 for simple admin tasks on MySQL-Server running on the localhost. Developed for my CS School Project.

This code is totally not perfect. And I admit it. My primary focus with the project was to get it all working with minimal semantic errors,
atleast from my side. And I don't intend to actively develop on the program anytime in the future, atleast not now.


# System Requirements:
This program should run on any computer with Python3, MySQL Server, and the below-mentioned Python Libraries installed.

# Installation Pre-requisites
1. The Following Python Libraries are required to execute the program:
    1. pyqt5
    2. pyqt5-tools
    3. mysql-connector


You may use the PIP package manager to install the above modules on your system Python3 environment or
using the adjacent library package manager bundled in with your IDE.

2. MySQL/MariaDB-Server from v5.1 and above, active and running.

# Installation and Running

1. Download the entire repo contents as a .zip and extract it in a folder on your computer.
2. Execute the python file MySQL-Frontendv2.0.py on your Python shell with above libraries installed on the computer.
3. Pls do not move around any .png or .ui file into other directories otherwise the python script may not run well.
4. You are done.
